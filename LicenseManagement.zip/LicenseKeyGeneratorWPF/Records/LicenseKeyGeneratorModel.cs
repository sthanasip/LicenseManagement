﻿namespace LicenseKeyGeneratorWPF.Records
{
    public record LicenseKeyGeneratorModel(string RequestKey, int NumberOfLicenses, string ExpiryDate);
}
